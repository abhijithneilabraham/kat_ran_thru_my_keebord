# kat_ran_thru_my_keebord
Scripting an experience of cat running through your keyboard.


I am not responsible if your pet cats go mad after running this script.

`pip install katran`


```
from katran import kat
kat.main(path-to-kat-audio-files) #make a folder  with cataudios and add its path for sound experience. 
```

[get cat audios here](https://drive.google.com/open?id=1lFrNsCQducjAalIpRT9ccUQF0ICJTn3T)

# kat_ran_thru_my_keebord
Scripting an experience of cat running through your keyboard.


`pip install katran`


```
import katran
katran.kat.katran()
```

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 19:35:17 2019

@author: abhijithneilabraham
"""

name='katran'
